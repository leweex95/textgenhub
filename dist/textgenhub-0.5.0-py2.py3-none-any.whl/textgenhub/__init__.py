import subprocess
from pathlib import Path
import sys
import shutil

def _ensure_node_deps():
    if not shutil.which("npm"):
        raise RuntimeError("npm is not installed or not in PATH")

    root = Path(__file__).parent
    node_modules = root / "node_modules"

    if not node_modules.exists():
        try:
            subprocess.run(
                ["npm", "install"],
                cwd=root,
                check=True,
                shell=True  # required on Windows
            )
        except subprocess.CalledProcessError as e:
            print(f"npm install failed: {e}", file=sys.stderr)
            raise

# Automatically install Node dependencies on first import
_ensure_node_deps()
