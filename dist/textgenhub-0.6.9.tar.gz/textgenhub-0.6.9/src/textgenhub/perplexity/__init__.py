from .perplexity import ask

__all__ = ['ask']