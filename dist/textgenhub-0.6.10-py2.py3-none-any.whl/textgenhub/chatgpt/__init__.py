from .chatgpt import ask

__all__ = ['ask']
