from .grok import ask

__all__ = ['ask']