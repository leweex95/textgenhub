from .deepseek import ask

__all__ = ['ask']
